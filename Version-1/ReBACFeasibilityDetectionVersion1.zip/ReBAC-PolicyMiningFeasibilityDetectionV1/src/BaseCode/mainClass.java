/*REBAC POLICY MINING FEASIBILITY DETECTION VERSION 1*/

/*PROGRAMMING ENVIRONMENT: ECLIPSE JAVASE-9*/

/*Motive: Given EAS and Relationship Graph (RG), is the ReBAC rule generation feasible? */

/*
 **************************
PROGRAM INPUT
***************************
This program needs three input files as follows:

1) isolatedVertex.txt

If the RG contains any isolated vertex, it must be noted in the file, one in each line. 
If there exists no isolated vertex, the file would remain empty.
**Vertex is a string

2) Edges.txt
This file contains directed labeled edge information of RG, one edge in each line in the following format:
	originating-vertex terminating-vertex edge-direction edge-label 

**originating-vertex, terminating-vertex, edge-direction, and edge-label are strings
**For now, edge-direction is restricted to be directed only, represented by "D". 

3) EAS.txt
This file contains authorization relation (AUTH), one  tuple in each line 


**************************
PROGRAM OUTPUT
**************************
This program needs generates two output files as follows:

1) finalRG.txt
This file contains the list of vertices and list of edges in RG. 

2) finalRuleOutput.txt
This file contains the generated rule, feasible/infeasible status, and rule minimization messages. 
In case of infeasibility, all infeasible authorization tuples are noted as well.
*/

package BaseCode;

//IMPORTED CLASS
import java.util.*;
import java.io.*;

//MAIN CLASS OF THE PROGRAM
public class mainClass {
	
	static BufferedWriter ruleOutput; //FINAL RULE OUTPUT FILE POINTER
	
	//READING AUTHORIZATION TUPLE FROM FILE AND STORING INTO EASdata
	public static void readEAS(String fname,LinkedList<String> EASdata) throws IOException
	{
		//INPUT FILE READING
		//creating File instance to reference text file in Java
        File input = new File(fname);
     
        //Creating Scanner instnace to read File in Java
        Scanner scnr = new Scanner(input);
     
        //Reading each line of file using Scanner class
        int lineNumber = 1;
        
        

        while(scnr.hasNextLine()){
            	String line = scnr.nextLine();
            	if(line.isEmpty())
            		break;
//            String splitstr[] = line.split(" ", 0); 
            
  //          System.out.println(line); 

//            	System.out.println("line "+lineNumber+" " + line);

            	lineNumber++;
                EASdata.add(line);
            }
            
		return;
	}


	
	
	//READING THE GIVEN EAS DATA
	public static void readIsolatedVertex(String fname,HashSet<String> IsolatedVertexList) throws IOException
	{
		//INPUT FILE READING
		//creating File instance to reference text file in Java
        File input = new File(fname);
     
        //Creating Scanner instnace to read File in Java
        Scanner scnr = new Scanner(input);
     
        //Reading each line of file using Scanner class
        int lineNumber = 1;
        
        

        while(scnr.hasNextLine()){
            	String line = scnr.nextLine();
            	if(line.isEmpty())
            		break;
     
            //	System.out.println("line "+lineNumber+" " + line);

            	lineNumber++;
            	IsolatedVertexList.add(line);
            }
            
		return;
	}

	
	
	public static void computeCombination(Graph RG,int total, int rsize, int loc,int array[], int value,LinkedList<String> presentLabelList,LinkedList<String> minimizedRuleList,LinkedList<String> EASdata)
	{
		if(minimizedRuleList.size() != 0)
			return; //already done
		// Current combination is ready to be printed, print it 
		if (loc == rsize) 
		{ 
//			for (int j=0; j<rsize; j++) 
				//System.out.print(array[j]+" "); 
//			System.out.println(""); 
	//		return; 
				//finding vertex pairs who has exactly same pathlabels or more than the current one  
			HashSet<String> duplicateVList = new HashSet<String>();
				for(String vPair: RG.graphLabelMap.keySet())
				{
				//	if(!s.equals(vPair)) //we dont need same pair
					
						HashSet<String> checkLabelList = RG.graphLabelMap.get(vPair);
						
						boolean dupFlag=true;
						
						for(int j=0; j<rsize; j++)
						{
							String L = presentLabelList.get(array[j]);
							if(!checkLabelList.contains(L))
							{	
								dupFlag=false;
								break;
						
							}
						}
						if(dupFlag == true)
							duplicateVList.add(vPair);
												
				}
				//DONE WITH ADDING THE VERTEX PAIR
				//NOW CHECKING WHETHER THEY ARE PART OF THE AUTHORIZATIONS
				boolean cflag=true;
				for(String temps: duplicateVList)
				{
					if(!EASdata.contains(temps))
					{
						cflag=false;
					//	System.out.println("this combination is Not feasible");
						return;
					}
				}
					
				//yes!!! this combo is feasible for this auth tuple. so prepare the Rule
				if(cflag == true)
				{
					for(int j=0; j<rsize; j++)
					{
						String L = presentLabelList.get(array[j]);
						minimizedRuleList.add(L);
					}
					
				}		
					
				
				return;
				
				
		} 

		// When no more elements are there to put in data[] 
		if (value >= total) 
			return; 

		// current is included, put next at next location 
		array[loc] = value; 
		computeCombination( RG,total, rsize, loc+1, array, value+1,presentLabelList,minimizedRuleList,EASdata); 
		
		// current is excluded, replace it with next (Note that 
		// i+1 is passed, but index is not changed) 
		computeCombination( RG,total, rsize, loc, array, value+1,presentLabelList,minimizedRuleList,EASdata); 
 
	}


	public static void minimizeRule(String s, HashSet<String> currentLabelList, Graph RG,LinkedList<String> minimizedRuleList,LinkedList<String> EASdata)
	{
		int n = currentLabelList.size();
		//copy the elements into a linkedlist
		LinkedList<String> presentLabelList = new LinkedList<String>();
		
		for(String copys: currentLabelList) //COPYING FOR DIRECT INDEX, HASHSET DOES NOT USE GET
			presentLabelList.add(copys);
		
		//int n = 5;
		int[] combStore = new int[n+1];

		//FINDING ALL POSSIBLE COMBINATIONS
		for(int i=1; i<=n; i++)
		{	
			computeCombination( RG,n, i, 0, combStore, 0,presentLabelList,minimizedRuleList,EASdata); 
			if(minimizedRuleList.size() != 0)
				break; //got result already
		}
		return;
	} 
	public static void makeCommentOnRule(HashSet<String> currentLabelList, LinkedList<String> minimizedRuleList) throws IOException
	{
		String rule="";
		
		int andCount = currentLabelList.size();
		for(String cterm: currentLabelList)
		{
			rule = rule + cterm;
			if(--andCount >0)
				rule = rule + " AND ";
		}
		//System.out.print(rule+" is minimized to ");
		ruleOutput.write(rule+" is minimized to ");
		
		rule="";
		
		andCount = minimizedRuleList.size();
		for(String cterm: minimizedRuleList)
		{
			rule = rule + cterm;
			if(--andCount >0)
				rule = rule + " AND ";
		}

		//System.out.println("--> "+rule);
		ruleOutput.write("--> "+rule+"\n");
	}

	public static String generateRule(String s, String Rule, HashSet<String> currentLabelList, Graph RG,LinkedList<String> EASdata) throws IOException
	{
		if(!Rule.equals(""))
		{
			Rule = Rule + " OR ";
		}
		
	//	Rule = Rule+"(";	//BEGINNING AN AND'ED TERM
		//WANT TO MINIMIZE RULE?? UNLOCK THE FOLLOWING BLOCK
		/******************************************************************/
		LinkedList<String> minimizedRuleList = new LinkedList<String>(); //it contains the minimized rule
		minimizeRule(s, currentLabelList, RG, minimizedRuleList, EASdata);
		int andCount = minimizedRuleList.size();
		for(String cterm: minimizedRuleList)
		{
			Rule = Rule + cterm;
			if(--andCount >0)
				Rule = Rule + " AND ";
			

		}
		/******************************************************************/
		
		//DONT WANT TO MINIMIZE?? UNCOMMENT THE FOLLOWING
/*		int andCount = currentLabelList.size();
		for(String cterm: currentLabelList)
		{
			Rule = Rule + cterm;
			if(--andCount >0)
				Rule = Rule + " AND ";
			

		}
*/
		//helping to show minimizations
		makeCommentOnRule(currentLabelList,minimizedRuleList);
		
	//	Rule = Rule+")"; //END OF A AND'ED TERM 

		
		return Rule;
	}
	
	//ENHANCE RG WITH EDGES, 1=comp, 2 perm, 3 comp-perm 
	public static void enhanceRG(int enhanceType, HashSet<String> vertexList, LinkedList<Edge> edgeList)
	{
		if(enhanceType == 0)
			return;

		
		//initiate the data structure to add edges
		LinkedList<Edge> compEdge = new LinkedList<Edge>();
		LinkedList<Edge> permEdge = new LinkedList<Edge>();
		LinkedList<Edge> comppermEdge = new LinkedList<Edge>();

		
		HashSet<String> relations = new HashSet<String>();
		
		for(Edge e1: edgeList)
			relations.add(e1.label);
 
		for(String s: vertexList)
		{	
			for(String d: vertexList)
			{	
				if(!s.equals(d))
				{
					
					for(String r: relations)
					{
						boolean eflag= true;
						//CHECK IF THE GENERATED ALREADY EXIST IN THE LIST
						for(Edge e1: edgeList)
						{
							if(s.equals(e1.u) && d.equals(e1.v) && r.equals(e1.label))
							{
								//this edge exists, hence add an inverse edge if needed
								if(enhanceType == 2 || enhanceType == 3)
									permEdge.add(new Edge(d, s, "P",r+"^"));
								eflag = false;
								break;
							}
						}
						
						if(eflag == true) //the generated edge (s,d,r) does not exists
						{
							if(enhanceType == 1 || enhanceType == 3) //add comp edges then
							{
								compEdge.add(new Edge(s,d,"C",r+"!"));
							}
						}
						
					}
					
					
				}					
			}
		}
		
		if(enhanceType == 3) //now compute complementary inverse then
		{
			for(Edge e2: compEdge)
			{
				//add inverse
				comppermEdge.add(new Edge(e2.v, e2.u, "CP", e2.label+"^"));
			}
		}
		
		//AT THE EDGE, MERGE EVERYTHING TO EDGELIST
		for(Edge e: compEdge)
			edgeList.add(e);
		
		for(Edge e: permEdge)
			edgeList.add(e);
		
		for(Edge e: comppermEdge)
			edgeList.add(e);
		
		
	}	

	//IT REMOVES DUPLICATE CONJUNCTIVE TERMS FROM THE GENERATED RULE
	public static String removeDuplicateFromRule(String rule)	
	{
		//IT CONTAINS THE SEPARATED CONJUNCTIVE TERMS 
		HashMap<Integer,HashSet<String>> cterms = new HashMap<Integer,HashSet<String>>();
		
		//A FLAG WHETHER THE CONJUNCTIVE TERMS ARE NEEDED OR NOT
		HashMap<Integer,Integer> removeMap = new HashMap<Integer,Integer>();

		if(rule == "") //NO NEED TO PROCESS IF RULE CONTAINS NOTHING
        	return rule;
		
		
        String splitstr[] = rule.split("OR", 0); //SPLIT THE CONJUNCTIVE TERMS
        
        int totalTerms = splitstr.length; //TOTAL NUMBER OF CONJUNCTIVE TERMS
        
            
        //THIL LOOP SPLITS THE OR'ED AND THEN AND'ED TERMS
        for(int j=0; j<totalTerms;j++)
        {	
        	removeMap.put(j, 0);

//            System.out.println("line "+splitstr[j]);
            String splitstr2[] = splitstr[j].split("AND", 0);
            
            //
            HashSet<String> tempr = new HashSet<String>();
            for(int k=0; k<splitstr2.length;k++)
            {          	
             //   System.out.println("line2 "+splitstr2[k].trim());
            	tempr.add(splitstr2[k].trim()); //ADDING TO HASHSET
            }
            cterms.put(j,tempr); //STORING ALL AND'ED TERMS
        }
        
        //System.out.println(cterms);
        
        //NOW REMOVE DUPLICATES
        for(int i=0; i<totalTerms; i++)
        {
    		if(removeMap.get(i)==1)
    			continue;

        	HashSet<String> currentLabelList = cterms.get(i);
        	
        	for(int j=0; j<totalTerms; j++)
            {
        		if(i==j || removeMap.get(j)==1) //ALREADY REMOVED?
        			continue;
        		
        		HashSet<String> checkLabelList = cterms.get(j);
        		
        		//now check whether currentLabelList is equal or subset of checkLabelList
				boolean Flag=true;
				
				for(String L: currentLabelList)
				{
					if(!checkLabelList.contains(L))
					{	
						Flag=false;
						break;
				
					}
				}
				if(Flag == true) //that means currentLabelList is equal or subset of checkLabelList, thus remove check 
				{
					removeMap.replace(j, 1);
				}

            
            }
        }

        
        String ruleop="";
        //now print the final rule
        for(int i=0; i<totalTerms; i++)
        {
        	if(removeMap.get(i) == 0)
        	{
            	if(!ruleop.equals(""))
            		ruleop = ruleop+" OR ";

        		String temprule="";
        		for(String L: cterms.get(i))
        		{
        			if(!temprule.equals(""))
        				temprule = temprule+" AND ";
       				temprule = temprule+L;
       			        			
        		}
        		
        		ruleop = ruleop+temprule;
        		
        	}
        
        		
        }
       // System.out.println("duplicate removed rule is "+ruleop);
       
        return ruleop;	
    
	}
	
	//DETERMINES FEASIBILITY OF THE GIVEN AUTHORIZATION TUPLES
	public static void computeFeasibility(LinkedList<String> EASdata, Graph RG, HashSet<String> unauthorizedPairList,HashSet<String> failedAuthList) throws IOException
	{
		ruleOutput.write("Starting to process the given authorizations\n");

		String RuleOp=""; //empty rule
		
		LinkedList<String> tempEASdata = new LinkedList<String>(); //temp store for EAS data
		HashMap<String, Integer> tempDoneAuth = new HashMap<String, Integer>(); //check if auth tuple is done
		
		for(String s: EASdata) //AUTH COPY AND MAP SET
		{
			tempEASdata.add(s);
			tempDoneAuth.put(s, 0);
		}
		
		//Main Loop	
		for(String s: tempEASdata) //FOR EACH TUPLE IN THE AUTHORIZATION
		{
			if(tempDoneAuth.get(s) == 1)
			{
				//System.out.println("Already processed "+s);
				continue;
				
			}	
			//System.out.println(" processing "+s);
			ruleOutput.write("Processing authorization tuple: "+s+"\n");
			
			//IT CONTAINS ALL PATHLABELS, THE CURRENTPAIR
			HashSet<String> currentLabelList = RG.graphLabelMap.get(s);
			HashSet<String> duplicateVList = new HashSet<String>();
			
			//special case if there is no path
			if(currentLabelList.size() == 0)
			{
				//System.out.println("No path exist for "+s);
				failedAuthList.add(s);
				tempDoneAuth.replace(s, 1);

				ruleOutput.write("No path exist for "+s+"\n");

				//return;
				continue;
			}
			
			//finding unauthorized vertex pairs who has exactly same pathlabels or more than the current one  
			for(String vPair: unauthorizedPairList)
			{
				if(!s.equals(vPair)) //we dont need same pair
				{
					HashSet<String> checkLabelList = RG.graphLabelMap.get(vPair);
					
					boolean dupFlag=true;
					
					for(String L: currentLabelList)
					{
						if(!checkLabelList.contains(L))
						{	
							dupFlag=false;
							break;
					
						}
					}
					if(dupFlag == true)
						duplicateVList.add(vPair);
						
				}
				
			}
			
			if(duplicateVList.isEmpty()) //MEANS NO UNAUTHORIZED VERTEX PAIR SATISFIES ALL PATHLABELS
			{
				//GREAT!
				//just remove the current tuple
				tempDoneAuth.replace(s, 1);
				//System.out.println("Feasible for "+s);
				//yes!!! feasible for this auth tuple. so prepare the Rule
				RuleOp = generateRule(s,RuleOp, currentLabelList, RG,EASdata);
				//System.out.println("Now the rule is "+RuleOp);
			}	
			else //MEANS SOME UNAUTHORIZED VERTEX PAIR SATISFIES ALL PATHLABELS
			{
				//NOT FEASIBLE, ADD THIS TO FAILURE LIST
				failedAuthList.add(s);
			//	System.out.println("Not feasible for "+s);
				tempDoneAuth.replace(s, 1);
			}
						
		}
		
		
		//want to remove duplicates conjunctive terms from rule? use the following
		RuleOp = removeDuplicateFromRule(RuleOp);
		
		if(failedAuthList.size() == 0)//yeeeee, feasible for all authorized tuple
		{
			System.out.println("Final result: Feasible for all");			
			//GENERATE THE RULE NOW
			System.out.print("The rule is: ");
			System.out.println(RuleOp);

			//writing to output file
			ruleOutput.write("Final result: Feasible for all\n");			
			//GENERATE THE RULE NOW
			ruleOutput.write("The rule is: ");
			ruleOutput.write(RuleOp);

		}
		else
		{
			System.out.println("Final result: Not Feasible for ");
			for(String unauth: failedAuthList)
				System.out.println(unauth);
			//GENERATE THE RULE NOW
			System.out.print("The incomplete rule is: ");
			System.out.println(RuleOp);

			//writing to output file
			ruleOutput.write("Final result: Not Feasible for the following:\n");
			for(String unauth: failedAuthList)
				ruleOutput.write(unauth+"\n");
			//GENERATE THE RULE NOW
			ruleOutput.write("The incomplete rule is: ");
			ruleOutput.write(RuleOp);
			
			
		}
	}
	
	
/*****************************MAIN CLASS, PROGRAM STARTS HERE*******************************/
	public static void main(String[] args) throws IOException 
	{
		//INITIALIZE DISCONNECTED/ISOLATED VERTEX LIST, IF THERE IS ANY
        HashSet<String> IsolatedVertexList = new HashSet<String>();
        
        //INITIALIZE UNAUTHORIZED PAIR LIST
        HashSet<String> unauthorizedPairList = new HashSet<String>();
		
		
		
        //EDGELIST IN THE GRAPH
        LinkedList<Edge> edgeList = new LinkedList<Edge>();
        //VERTEX LIST
        HashSet<String> vertexList = new HashSet<String>();

        //ADD ISOLATED VERTEX IF THERE IS ANY  
        readIsolatedVertex("isolatedVertex.txt", IsolatedVertexList);
        
        //COPYING ISOLATED VETICES TO VERTEX LIST
        for(String u: IsolatedVertexList)
         	vertexList.add(u);
         
        
		//GRAPH EDGE FILE NAME TO BE READ
		String inputFileName = "Edges.txt";

		//INPUT FILE READING
		//creating File instance to reference text file in Java
        File input = new File(inputFileName);
     
        //Creating Scanner instnace to read File in Java
        Scanner scnr = new Scanner(input);
     
        //Reading each line of file using Scanner class
        int lineNumber = 1;
        
        
        //INPUT FILE READING LOOP
        while(scnr.hasNextLine()){
            String line = scnr.nextLine();
            if(line.isEmpty())
            	break;
            String splitstr[] = line.split(" ", 0); 
            
         //   System.out.println(line); 
        

        	//copying labels
            for(int j=3; j<splitstr.length;j++)
            {	
//            	labelList.add(splitstr[j]);

                Edge edge = new Edge(splitstr[0],splitstr[1],splitstr[2],splitstr[j]);

                vertexList.add(edge.u); //ADDING VERTEX PAIR
                vertexList.add(edge.v);
                edgeList.add(edge); //ADDING EDGE

           //     System.out.println("line "+lineNumber+" " + edge.u + " :" + edge.v+" "+edge.label);

                
            }
            
            lineNumber++;
            

        
        
        }     

		//DONE WITH GRAPH READING


        
        //ENHANCE GRAPH WITH COMPLEMENTARY PATH (1), PERMISSIVE(2), COMP-PERMISSIVE(3), NO-CHANGE(0)
        enhanceRG(0,vertexList,edgeList);
        
        //NOW CREATE THE GRAPH
        
        Graph RG = new Graph(vertexList,edgeList);
        
        RG.printGraph();
        
     //   RG.printAllSimplePath("A","B");
        
        RG.computeAllLabels();
        
        //READ AUTHORIZATION DATA NOW
		LinkedList<String> EASdata = new LinkedList<String>();

        readEAS("EAS.txt", EASdata);
        
        //NOW FIND FEASIBILITY
        //FIND UNAUTHORIZED TUPLES FIRST
        RG.findUnauthorizedPairs(EASdata, unauthorizedPairList);
        
        //CHECK VALIDITY OF EAS DATA!!!
        if(!RG.findValidityEAS(EASdata))
        {
        	System.out.println("EAS data is invalid");
        	return;
        }
        else
        	System.out.println("EAS data is valid");
        
        //BIG STEP
        
        //INITIALIZE FAILED AUTH LIST
        HashSet<String> failedAuthList = new HashSet<String>();

        //OPEN FINAL RULE OUTPUT FILE NOW
		ruleOutput = new BufferedWriter(new FileWriter("finalRuleOutput.txt"));

        computeFeasibility(EASdata,RG,unauthorizedPairList,failedAuthList);   
        ruleOutput.close();
        
	}




}





