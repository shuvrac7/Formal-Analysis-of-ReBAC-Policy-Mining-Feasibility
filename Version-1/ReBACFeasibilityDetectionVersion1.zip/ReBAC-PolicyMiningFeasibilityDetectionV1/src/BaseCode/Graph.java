package BaseCode;

import java.io.*;
import java.io.IOException;
import java.util.*;

//GRAPH CLASS CONTAINS CODE THAT MANIPULATES THE RELATIONSHIP GRAPH

public class Graph {
	
	//GRAPH CLASS MEMBER VARIABLES
	HashSet<String> vertexList=new HashSet<String>(); //VERTEX LIST
	
	LinkedList<Edge> edgeList=new LinkedList<Edge>(); //EDGE LIST
	
	HashMap<String,Integer> visitVertex= new HashMap<String,Integer>(); //NEEDED FOR GRAPH DFS TRAVERSAL
	HashMap<Edge,Integer> visitEdge = new HashMap<Edge,Integer>(); ////NEEDED FOR GRAPH DFS TRAVERSAL

	//VERTEX PAIR TO SET OF PATHLABELS MAPPING
	HashMap<String,HashSet<String>> graphLabelMap= new HashMap<String,HashSet<String>>(); 
	
	//PATHLABEL TO SATISFIED VERTEX PAIR MAPPING
	HashMap<String,HashSet<String>> label2vMap= new HashMap<String,HashSet<String>>();

	//CONSTRUCTOR INITIALIZING GRAPH WITH VERTEX AND EDGELIST
	Graph(HashSet<String> vList,LinkedList<Edge> eList)
	{
		for(String s: vList)
		{	
			vertexList.add(s);
			visitVertex.put(s,0);

		}
		for(Edge e: eList)
		{
			edgeList.add(e);
		    visitEdge.put(e,0);
		}
	}
	
	//
	void findUnauthorizedPairs(LinkedList<String> EASdata, HashSet<String> unauthorizedPairList)
	{
		
		for(String s: vertexList)
		{	
			for(String d: vertexList)
			{	
				if(s.equals(d)) //loop not allowed
					continue;
				
				String pair = s+" "+d;
				
				//CHECK IF THE CURRENT PAIR IS UNAUTHORIZED OR NOT
				boolean cflag = true;
				for(String m: EASdata)
				{
					if(m.equals(pair))
					{
						cflag = false;
						break;
					}
				}
				
				if(cflag == true)
				{
				//	System.out.println("UNAuth: "+pair);
					unauthorizedPairList.add(pair);
				}
			}
		}
		
		
		
	}
	//CHECK EAS DATA VALIDITY
	//OPTIONAL, BUT USEFUL
	boolean findValidityEAS(LinkedList<String> EASdata)
	{
		for(String m: EASdata)
		{
			  String splitstr[] = m.split(" ", 0); //SPLIT THE auth tuple
		     // System.out.println(splitstr[0]+" "+splitstr[1]);  
			  if(!vertexList.contains(splitstr[0]) || !vertexList.contains(splitstr[1]))
			  {
				  System.out.println("Error in given Auth data "+m);
				  return false;
			  }
		}
		
		return true;
		
	}
	
	
	
	//COMPUTES ALL POSSIBLE PATHLABELS, STORES VERTEX PAIR TO PATHLABEL SET MAPPING
	void computeAllLabels()
	{
		for(String s: vertexList)
		{	
			for(String d: vertexList)
			{	
				if(!s.equals(d))
				{
					LinkedList<String> PS = new LinkedList<String>();
					HashSet<String> LABELS = new HashSet<String>();

					modifiedDFSVisit(s,d,PS,LABELS,"",""); 
					graphLabelMap.put(s+" "+d, LABELS); //STORING THE MAPPING
					
					
				}					
			}
		}
		
		//System.out.println(graphLabelMap);

	}
	
	//PRINT THE GRAPH VERTICES AND EDGE LIST
	void printGraph() throws IOException
	{
		//print graph to a file named finalRG.txt
		BufferedWriter out = new BufferedWriter(new FileWriter("finalRG.txt"));
		out.write("List of vertices\n");

		//System.out.println("Vertex list is:");
		for(String s: vertexList)
		{	
			out.write(s+" ");
	//		System.out.println(s);

		}

		out.write("\nList of edges\n");
	//	System.out.println("Edge list is:");
	
		for(Edge e: edgeList)
		{
		//	System.out.println("u="+e.u+" v="+e.v+" r="+e.label);
			out.write(e.u+" "+e.v+" "+e.label+"\n");
		
		}
		out.close();
		
	}
	
	//GIVEN A VERTEX PAIR, FINDS ALL POSSIBLE SIMPLE PATH BETWEEN THEM
	void printAllSimplePath(String src, String dest)
	{
		LinkedList<String> PS = new LinkedList<String>();
		HashSet<String> LABELS = new HashSet<String>();

		modifiedDFSVisit(src,dest,PS,LABELS,"",""); 
	} 

	//MODIFIED DFS GRAPH VISIT, SUPPORTING METHOD OF ALL POSSIBLE SIMPLE PATH
	void modifiedDFSVisit(String src, String dest,LinkedList<String> PS,HashSet<String> LABELS,String tempPath,String labelList )
	{
		if(src.equals(dest))
		{
			PS.add(tempPath);
			LABELS.add(labelList);
		//	System.out.println(tempPath);
		//	System.out.println(labelList);

			return;
		}
		
		visitVertex.put(src, 1);
		for(Edge e: edgeList)
		{
			if(e.u.equals(src) && visitEdge.get(e)==0 && visitVertex.get(e.v)==0)
			{
				if(tempPath.equals(""))
					modifiedDFSVisit(e.v, dest, PS, LABELS,tempPath+"("+e.u+","+e.v+","+e.label+")",e.label);
				else
					modifiedDFSVisit(e.v, dest, PS, LABELS,tempPath+"."+"("+e.u+","+e.v+","+e.label+")",labelList+"."+e.label);
				
			}
		}
		visitVertex.put(src, 0);

		for(Edge e: edgeList)
		{
			if(e.u.equals(src))
			{
				visitEdge.put(e, 0);
								
			}
		}

		
	}
	
	

}

