package BaseCode;

//EDGE CLASS FOR RELATIONSHIP GRAPH
import java.util.LinkedList;

public class Edge {
	String u,v;
	String Status; //directed or undirected;
	String label; //edge label
	
	Edge(String u,String v, String status, String edgelabel)
	{
		this.u = u;
		this.v = v;
		this.Status = status;
		label = edgelabel;

		//printing edges
		/*for(String l: edgelabels)
		{
			System.out.println(l);
		}*/
	}

}

